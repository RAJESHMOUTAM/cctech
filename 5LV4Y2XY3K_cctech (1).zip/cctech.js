let userContainer = document.getElementById('userContainer')

let results = []

function createAndAppend(user) {
    let name = user.name.title + ' ' + user.name.first + ' ' + user.name.last
    let imageurl = user.picture.large
    let email = user.email
    let address = user.location.street.number + ', ' + user.location.street.name + ', ' + user.location.city + ', ' + user.location.state + ', ' + user.location.country + ', ' + user.location.postcode

    let userEl = document.createElement('div')
    userEl.classList.add('user-card')
    userContainer.appendChild(userEl)

    let userImg = document.createElement('img')
    userImg.src = imageurl
    userImg.classList.add('user-image')
    userEl.appendChild(userImg)

    let verticalLine = document.createElement('div')
    verticalLine.classList.add('line')
    userEl.appendChild(verticalLine)

    let detailContainer = document.createElement('div')
    detailContainer.classList.add('detail-container')
    userEl.appendChild(detailContainer)

    let nameEl = document.createElement('p')
    nameEl.textContent = name
    nameEl.classList.add('name')
    detailContainer.appendChild(nameEl)

    let mailEl = document.createElement('p')
    mailEl.textContent = email
    mailEl.classList.add('mail')
    detailContainer.appendChild(mailEl)

    let addressEl = document.createElement('p')
    addressEl.textContent = address
    addressEl.classList.add('address')
    detailContainer.appendChild(addressEl)

}

function displayUser(results) {
    for (let user of results) {
        createAndAppend(user)
    }

}

function getUser() {
    let options = {
        method: 'GET'
    };

    let url = 'https://randomuser.me/api/?results=10'
    fetch(url, options)
        .then(function(response) {
            return response.json()
        })
        .then(function(jsonData) {
            let {
                results
            } = jsonData
            displayUser(results)
        })
}
getUser()